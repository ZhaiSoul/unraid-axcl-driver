/**************************************************************************************************
 *
 * Copyright (c) 2024 Axera Semiconductor Co., Ltd. All Rights Reserved.
 *
 * This source file is the property of Axera Semiconductor Co., Ltd. and
 * may not be copied or distributed in any isomorphic form without the prior
 * written consent of Axera Semiconductor Co., Ltd.
 *
 **************************************************************************************************/

#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/kthread.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/tty.h>
#include <linux/tty_driver.h>
#include <linux/tty_flip.h>
#include <linux/tty_port.h>
#include <linux/types.h>
#include <linux/version.h>
#include <linux/vmalloc.h>
#include <linux/wait.h>

#include "ax_pcie_msg_transfer.h"

#define VTTY_DRIVER_NAME "vtty"
#define VTTY_DEFAULT_PORT 80
#define VTTY_MAX_PAYLOAD 4096
#define VTTY_MIN_PAYLOAD 256
#define VTTY_DEFAULT_FIFO (1024 * 1024)
#define VTTY_FLIP_RETRY_MS 10
#define VTTY_DEFAULT_PKT_COUNT 256

static int target_id = -1;
static bool check_remote;
static unsigned int vtty_port = VTTY_DEFAULT_PORT;
static unsigned int rx_buf_size = VTTY_DEFAULT_FIFO;
static unsigned int payload_size = VTTY_MAX_PAYLOAD;
static char tty_dev_name[32] = "ttyAXCL";

module_param(target_id, int, 0444);
module_param(check_remote, bool, 0444);
module_param_named(port, vtty_port, uint, 0444);
module_param(rx_buf_size, uint, 0444);
module_param(payload_size, uint, 0444);
module_param_string(dev_name, tty_dev_name, sizeof(tty_dev_name), 0444);

struct vtty_stats {
	atomic64_t rx_packets;
	atomic64_t rx_bytes;
	atomic64_t rx_dropped;
	atomic64_t rx_flip_short;
	atomic64_t rx_bad_len;
	atomic64_t rx_no_free_pkt;
	atomic64_t tx_packets;
	atomic64_t tx_bytes;
	atomic64_t tx_send_err;
};

struct vtty_pkt {
	struct list_head node;
	unsigned int data_len;
	unsigned int data_off;
	unsigned int data_size;
	u8 data[];
};

struct vtty_dev {
	struct tty_port tty_port;
	struct ax_transfer_handle *msg_handle;
	struct task_struct *rx_thread;
	void *rx_pkt_pool;
	unsigned int rx_pkt_count;
	unsigned int rx_pkt_stride;
	struct vtty_pkt *rx_pending_pkt;
	struct list_head rx_free_list;
	struct list_head rx_ready_list;
	spinlock_t rx_lock;
	spinlock_t discard_lock;
	struct mutex tx_mutex;
	wait_queue_head_t rx_wait;
	atomic_t opened;
	atomic_t stopping;
	atomic_t throttled;
	unsigned int target;
	unsigned int minor;
	unsigned int rx_ready_count;
	void *discard_buf;
	bool registered;
	bool port_initialized;
	struct vtty_stats stats;
};

static struct vtty_dev *vtty_devs;
static unsigned int vtty_dev_count;
static struct tty_driver *vtty_driver;
static const struct tty_port_operations vtty_port_ops = { };

static unsigned int vtty_pkt_count_from_size(unsigned int size)
{
	unsigned int max_payload = payload_size;

	if (max_payload < VTTY_MIN_PAYLOAD)
		max_payload = VTTY_MIN_PAYLOAD;
	else if (max_payload > VTTY_MAX_PAYLOAD)
		max_payload = VTTY_MAX_PAYLOAD;

	return max_t(unsigned int, DIV_ROUND_UP(size, max_payload), VTTY_DEFAULT_PKT_COUNT);
}

static int vtty_check_target(unsigned int target)
{
	if (!check_remote)
		return 0;

	return ax_pcie_msg_check_remote(target) ? -ENODEV : 0;
}

static int vtty_collect_targets(unsigned int *targets, unsigned int *count)
{
	int ids[MAX_DEV_NUMBER];
	int nr_ids;
	int ret;
	int i;

	if (target_id >= 0) {
		ret = vtty_check_target(target_id);
		if (ret)
			return ret;
		targets[0] = target_id;
		*count = 1;
		return 0;
	}

	nr_ids = ax_pcie_msg_getremoteids(ids);
	if (nr_ids <= 0)
		return -ENODEV;

	*count = 0;
	for (i = 0; i < nr_ids && *count < MAX_DEV_NUMBER; i++) {
		ret = vtty_check_target(ids[i]);
		if (ret)
			return ret;
		targets[*count] = ids[i];
		(*count)++;
	}

	return *count ? 0 : -ENODEV;
}

static struct vtty_pkt *vtty_rx_pkt_alloc(struct vtty_dev *vdev)
{
	struct vtty_pkt *pkt = NULL;
	unsigned long flags;

	spin_lock_irqsave(&vdev->rx_lock, flags);
	if (!list_empty(&vdev->rx_free_list)) {
		pkt = list_first_entry(&vdev->rx_free_list, struct vtty_pkt, node);
		list_del_init(&pkt->node);
	}
	spin_unlock_irqrestore(&vdev->rx_lock, flags);

	return pkt;
}

static void vtty_rx_pkt_free(struct vtty_dev *vdev, struct vtty_pkt *pkt)
{
	unsigned long flags;

	pkt->data_len = 0;
	pkt->data_off = 0;

	spin_lock_irqsave(&vdev->rx_lock, flags);
	list_add_tail(&pkt->node, &vdev->rx_free_list);
	spin_unlock_irqrestore(&vdev->rx_lock, flags);
}

static void vtty_rx_pkt_queue(struct vtty_dev *vdev, struct vtty_pkt *pkt)
{
	unsigned long flags;

	spin_lock_irqsave(&vdev->rx_lock, flags);
	list_add_tail(&pkt->node, &vdev->rx_ready_list);
	vdev->rx_ready_count++;
	spin_unlock_irqrestore(&vdev->rx_lock, flags);
	wake_up_interruptible(&vdev->rx_wait);
}

static struct vtty_pkt *vtty_rx_pkt_dequeue(struct vtty_dev *vdev)
{
	struct vtty_pkt *pkt = NULL;
	unsigned long flags;

	spin_lock_irqsave(&vdev->rx_lock, flags);
	if (!list_empty(&vdev->rx_ready_list)) {
		pkt = list_first_entry(&vdev->rx_ready_list, struct vtty_pkt, node);
		list_del_init(&pkt->node);
		vdev->rx_ready_count--;
	}
	spin_unlock_irqrestore(&vdev->rx_lock, flags);

	return pkt;
}

static int vtty_discard_packet(struct vtty_dev *vdev,
					       struct ax_transfer_handle *handle,
					       unsigned int len)
{
	unsigned long flags;
	int ret;

	if (len > AX_SHARED_SENDMEM_SIZE)
		return -EMSGSIZE;

	spin_lock_irqsave(&vdev->discard_lock, flags);
	ret = ax_pcie_msg_data_recv(handle, vdev->discard_buf, len);
	spin_unlock_irqrestore(&vdev->discard_lock, flags);

	atomic64_inc(&vdev->stats.rx_dropped);

	return ret;
}

static int vtty_notifier_recv(void *handle, void *buf, unsigned int len)
{
	struct ax_transfer_handle *transfer_handle = handle;
	unsigned int max_payload = payload_size;
	struct vtty_dev *vdev;
	struct vtty_pkt *pkt;
	int ret;

	if (!transfer_handle)
		return -EINVAL;

	vdev = (struct vtty_dev *)transfer_handle->data;
	if (!vdev || atomic_read(&vdev->stopping))
		return -ENODEV;
	if (max_payload < VTTY_MIN_PAYLOAD)
		max_payload = VTTY_MIN_PAYLOAD;
	else if (max_payload > VTTY_MAX_PAYLOAD)
		max_payload = VTTY_MAX_PAYLOAD;

	if (!len || len > max_payload) {
		atomic64_inc(&vdev->stats.rx_bad_len);
		return vtty_discard_packet(vdev, transfer_handle, len);
	}

	pkt = vtty_rx_pkt_alloc(vdev);
	if (!pkt) {
		atomic64_inc(&vdev->stats.rx_no_free_pkt);
		return vtty_discard_packet(vdev, transfer_handle, len);
	}
	if (len > pkt->data_size) {
		atomic64_inc(&vdev->stats.rx_bad_len);
		ret = vtty_discard_packet(vdev, transfer_handle, len);
		vtty_rx_pkt_free(vdev, pkt);
		return ret;
	}

	ret = ax_pcie_msg_data_recv(transfer_handle, pkt->data, len);
	if (ret != len) {
		atomic64_inc(&vdev->stats.rx_bad_len);
		vtty_rx_pkt_free(vdev, pkt);
		return ret < 0 ? ret : -EINVAL;
	}

	pkt->data_len = len;
	pkt->data_off = 0;
	vtty_rx_pkt_queue(vdev, pkt);

	return 0;
}
static int vtty_push_pending(struct vtty_dev *vdev)
{
	struct vtty_pkt *pkt = vdev->rx_pending_pkt;
	unsigned int copied;
	unsigned int left;

	if (!pkt)
		return 0;

	if (!atomic_read(&vdev->opened)) {
		vtty_rx_pkt_free(vdev, pkt);
		vdev->rx_pending_pkt = NULL;
		return 0;
	}

	left = pkt->data_len - pkt->data_off;
	if (!left) {
		vtty_rx_pkt_free(vdev, pkt);
		vdev->rx_pending_pkt = NULL;
		return 0;
	}

	copied = tty_insert_flip_string(&vdev->tty_port, pkt->data + pkt->data_off, left);
	if (!copied) {
		atomic64_inc(&vdev->stats.rx_flip_short);
		msleep(VTTY_FLIP_RETRY_MS);
		return -EAGAIN;
	}

	pkt->data_off += copied;
	atomic64_add(copied, &vdev->stats.rx_bytes);
	tty_flip_buffer_push(&vdev->tty_port);

	if (copied < left) {
		atomic64_inc(&vdev->stats.rx_flip_short);
		return -EAGAIN;
	}

	atomic64_inc(&vdev->stats.rx_packets);
	vtty_rx_pkt_free(vdev, pkt);
	vdev->rx_pending_pkt = NULL;

	return 0;
}

static int vtty_rx_thread(void *data)
{
	struct vtty_dev *vdev = data;
	struct vtty_pkt *pkt;
	int ret;

	while (!kthread_should_stop()) {
		ret = wait_event_interruptible(vdev->rx_wait,
			atomic_read(&vdev->stopping) ||
			(!atomic_read(&vdev->throttled) &&
			 (vdev->rx_pending_pkt || vdev->rx_ready_count)));
		if (ret && !kthread_should_stop())
			continue;
		if (atomic_read(&vdev->stopping) || kthread_should_stop())
			break;
		if (atomic_read(&vdev->throttled))
			continue;

		if (vdev->rx_pending_pkt) {
			vtty_push_pending(vdev);
			continue;
		}

		pkt = vtty_rx_pkt_dequeue(vdev);
		if (!pkt)
			continue;

		vdev->rx_pending_pkt = pkt;
		vtty_push_pending(vdev);
	}

	return 0;
}

static int vtty_tty_open(struct tty_struct *tty, struct file *filp)
{
	struct vtty_dev *vdev;
	int ret;

	if (tty->index >= vtty_dev_count)
		return -ENODEV;

	vdev = &vtty_devs[tty->index];
	if (!vdev->msg_handle || atomic_read(&vdev->stopping))
		return -ENODEV;

	tty->driver_data = vdev;
	ret = tty_port_open(&vdev->tty_port, tty, filp);
	if (ret)
		return ret;

	atomic_inc(&vdev->opened);
	atomic_set(&vdev->throttled, 0);
	wake_up_interruptible(&vdev->rx_wait);

	return 0;
}

static void vtty_tty_close(struct tty_struct *tty, struct file *filp)
{
	struct vtty_dev *vdev = tty->driver_data;

	if (!vdev)
		return;

	if (atomic_dec_if_positive(&vdev->opened) <= 0) {
		atomic_set(&vdev->throttled, 0);
		wake_up_interruptible(&vdev->rx_wait);
	}
	tty_port_close(&vdev->tty_port, tty, filp);
}

static ssize_t vtty_write_buf(struct vtty_dev *vdev, const u8 *buf, size_t count)
{
	unsigned int max_payload = payload_size;
	size_t written = 0;
	unsigned int chunk;
	int ret = 0;

	if (!vdev || !buf)
		return -ENODEV;
	if (!count)
		return 0;
	if (max_payload < VTTY_MIN_PAYLOAD)
		max_payload = VTTY_MIN_PAYLOAD;
	else if (max_payload > VTTY_MAX_PAYLOAD)
		max_payload = VTTY_MAX_PAYLOAD;
	if (!vdev->msg_handle || atomic_read(&vdev->stopping))
		return -ENODEV;

	mutex_lock(&vdev->tx_mutex);
	while (written < count) {
		chunk = min_t(size_t, max_payload, count - written);
		ret = ax_pcie_msg_send(vdev->msg_handle, buf + written, chunk);
		if (ret < 0)
			break;

		written += chunk;
		atomic64_inc(&vdev->stats.tx_packets);
		atomic64_add(chunk, &vdev->stats.tx_bytes);
	}
	mutex_unlock(&vdev->tx_mutex);

	if (ret < 0) {
		atomic64_inc(&vdev->stats.tx_send_err);
		ret = -EIO;
	}

	return written ? written : ret;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 6, 0)
static ssize_t vtty_tty_write(struct tty_struct *tty, const u8 *buf, size_t count)
#else
static int vtty_tty_write(struct tty_struct *tty, const unsigned char *buf, int count)
#endif
{
	return vtty_write_buf(tty->driver_data, buf, count);
}

static unsigned int vtty_write_room(struct tty_struct *tty)
{
	struct vtty_dev *vdev = tty->driver_data;

	if (!vdev || !vdev->msg_handle || atomic_read(&vdev->stopping))
		return 0;
	if (payload_size < VTTY_MIN_PAYLOAD)
		return VTTY_MIN_PAYLOAD;
	if (payload_size > VTTY_MAX_PAYLOAD)
		return VTTY_MAX_PAYLOAD;

	return payload_size;
}

static void vtty_throttle(struct tty_struct *tty)
{
	struct vtty_dev *vdev = tty->driver_data;

	if (vdev)
		atomic_set(&vdev->throttled, 1);
}

static void vtty_unthrottle(struct tty_struct *tty)
{
	struct vtty_dev *vdev = tty->driver_data;

	if (vdev) {
		atomic_set(&vdev->throttled, 0);
		wake_up_interruptible(&vdev->rx_wait);
	}
}

static const struct tty_operations vtty_ops = {
	.open = vtty_tty_open,
	.close = vtty_tty_close,
	.write = vtty_tty_write,
	.write_room = vtty_write_room,
	.throttle = vtty_throttle,
	.unthrottle = vtty_unthrottle,
};

static int vtty_pkt_pool_alloc(struct vtty_dev *vdev)
{
	unsigned int pkt_count = vtty_pkt_count_from_size(rx_buf_size);
	unsigned int stride = ALIGN(sizeof(struct vtty_pkt) + payload_size,
				    sizeof(unsigned long));
	size_t pool_size = (size_t)pkt_count * stride;
	u8 *pool;
	unsigned int i;

	if (pkt_count && pool_size / pkt_count != stride)
		return -ENOMEM;

	vdev->rx_pkt_pool = vzalloc(pool_size);
	if (!vdev->rx_pkt_pool)
		return -ENOMEM;
	vdev->rx_pkt_count = pkt_count;
	vdev->rx_pkt_stride = stride;

	vdev->discard_buf = vmalloc(AX_SHARED_SENDMEM_SIZE);
	if (!vdev->discard_buf) {
		vfree(vdev->rx_pkt_pool);
		vdev->rx_pkt_pool = NULL;
		return -ENOMEM;
	}

	pool = vdev->rx_pkt_pool;
	for (i = 0; i < pkt_count; i++) {
		struct vtty_pkt *pkt = (struct vtty_pkt *)(pool + i * stride);

		INIT_LIST_HEAD(&pkt->node);
		pkt->data_size = payload_size;
		list_add_tail(&pkt->node, &vdev->rx_free_list);
	}

	return 0;
}

static void vtty_pkt_pool_free(struct vtty_dev *vdev)
{
	vfree(vdev->discard_buf);
	vdev->discard_buf = NULL;
	vfree(vdev->rx_pkt_pool);
	vdev->rx_pkt_pool = NULL;
	vdev->rx_pkt_count = 0;
	vdev->rx_pkt_stride = 0;
}

static int vtty_register_driver(unsigned int count)
{
	int ret;

	vtty_driver = tty_alloc_driver(count,
					 TTY_DRIVER_REAL_RAW | TTY_DRIVER_DYNAMIC_DEV);
	if (IS_ERR(vtty_driver)) {
		ret = PTR_ERR(vtty_driver);
		vtty_driver = NULL;
		return ret;
	}

	vtty_driver->owner = THIS_MODULE;
	vtty_driver->driver_name = VTTY_DRIVER_NAME;
	vtty_driver->name = tty_dev_name;
	vtty_driver->major = 0;
	vtty_driver->minor_start = 0;
	vtty_driver->type = TTY_DRIVER_TYPE_SERIAL;
	vtty_driver->subtype = SERIAL_TYPE_NORMAL;
	vtty_driver->init_termios = tty_std_termios;
	vtty_driver->init_termios.c_cflag = B115200 | CS8 | CREAD | CLOCAL;
	vtty_driver->init_termios.c_iflag = IGNPAR;
	vtty_driver->init_termios.c_oflag = 0;
	vtty_driver->init_termios.c_lflag = 0;
	tty_set_operations(vtty_driver, &vtty_ops);

	ret = tty_register_driver(vtty_driver);
	if (ret) {
		tty_driver_kref_put(vtty_driver);
		vtty_driver = NULL;
		return ret;
	}

	return 0;
}

static void vtty_unregister_driver(void)
{
	if (!vtty_driver)
		return;

	tty_unregister_driver(vtty_driver);
	tty_driver_kref_put(vtty_driver);
	vtty_driver = NULL;
}

static int vtty_register_device(struct vtty_dev *vdev)
{
	struct device *dev;

	dev = tty_port_register_device(&vdev->tty_port, vtty_driver,
					    vdev->minor, NULL);
	if (IS_ERR(dev))
		return PTR_ERR(dev);

	vdev->registered = true;

	return 0;
}

static void vtty_unregister_device(struct vtty_dev *vdev)
{
	if (!vtty_driver || !vdev->registered)
		return;

	tty_port_unregister_device(&vdev->tty_port, vtty_driver, vdev->minor);
	vdev->registered = false;
}

static void vtty_cleanup_dev(struct vtty_dev *vdev)
{
	if (!vdev)
		return;

	atomic_set(&vdev->stopping, 1);
	wake_up_interruptible(&vdev->rx_wait);

	if (vdev->rx_thread) {
		kthread_stop(vdev->rx_thread);
		vdev->rx_thread = NULL;
	}
	vtty_unregister_device(vdev);

	if (vdev->msg_handle) {
		vdev->msg_handle->msg_notifier_recvfrom = NULL;
		vdev->msg_handle->data = 0;
		ax_pcie_msg_close(vdev->msg_handle);
		vdev->msg_handle = NULL;
	}

	if (vdev->port_initialized) {
		tty_port_destroy(&vdev->tty_port);
		vdev->port_initialized = false;
	}

	vtty_pkt_pool_free(vdev);
}

static int vtty_init_dev(struct vtty_dev *vdev, unsigned int target, unsigned int minor)
{
	int ret;

	memset(vdev, 0, sizeof(*vdev));
	vdev->target = target;
	vdev->minor = minor;
	atomic_set(&vdev->opened, 0);
	atomic_set(&vdev->stopping, 0);
	atomic_set(&vdev->throttled, 0);
	INIT_LIST_HEAD(&vdev->rx_free_list);
	INIT_LIST_HEAD(&vdev->rx_ready_list);
	spin_lock_init(&vdev->rx_lock);
	mutex_init(&vdev->tx_mutex);
	spin_lock_init(&vdev->discard_lock);
	init_waitqueue_head(&vdev->rx_wait);
	tty_port_init(&vdev->tty_port);
	vdev->port_initialized = true;
	vdev->tty_port.ops = &vtty_port_ops;

	ret = vtty_pkt_pool_alloc(vdev);
	if (ret)
		goto err_cleanup;

	if (find_device_handle(target, vtty_port)) {
		ret = -EBUSY;
		goto err_cleanup;
	}

	vdev->msg_handle = ax_pcie_open(target, vtty_port);
	if (!vdev->msg_handle) {
		ret = -ENODEV;
		goto err_cleanup;
	}
	vdev->msg_handle->priority = 0;
	vdev->msg_handle->data = (unsigned long)vdev;
	vdev->msg_handle->msg_notifier_recvfrom = vtty_notifier_recv;

	ret = vtty_register_device(vdev);
	if (ret)
		goto err_cleanup;

	vdev->rx_thread = kthread_run(vtty_rx_thread, vdev,
					"pcie_vtty_rx/%u", minor);
	if (IS_ERR(vdev->rx_thread)) {
		ret = PTR_ERR(vdev->rx_thread);
		vdev->rx_thread = NULL;
		goto err_cleanup;
	}

	pr_info("vtty: /dev/%s%u target %u port %u ready, rx_pkts %u payload %u\n",
		tty_dev_name, minor, target, vtty_port,
		vtty_pkt_count_from_size(rx_buf_size), payload_size);

	return 0;

err_cleanup:
	vtty_cleanup_dev(vdev);

	return ret;
}

static int __init vtty_init(void)
{
	unsigned int targets[MAX_DEV_NUMBER];
	unsigned int count;
	unsigned int i;
	int ret;

	if (payload_size < VTTY_MIN_PAYLOAD)
		payload_size = VTTY_MIN_PAYLOAD;
	else if (payload_size > VTTY_MAX_PAYLOAD)
		payload_size = VTTY_MAX_PAYLOAD;
	if (vtty_port >= MAX_MSG_PORTS)
		return -EINVAL;

	ret = vtty_collect_targets(targets, &count);
	if (ret)
		return ret;

	vtty_devs = kcalloc(count, sizeof(*vtty_devs), GFP_KERNEL);
	if (!vtty_devs)
		return -ENOMEM;
	vtty_dev_count = count;

	ret = vtty_register_driver(count);
	if (ret)
		goto err_free_devs;

	for (i = 0; i < count; i++) {
		ret = vtty_init_dev(&vtty_devs[i], targets[i], i);
		if (ret)
			goto err_cleanup_devs;
	}

	return 0;

err_cleanup_devs:
	while (i--)
		vtty_cleanup_dev(&vtty_devs[i]);
	vtty_unregister_driver();
err_free_devs:
	kfree(vtty_devs);
	vtty_devs = NULL;
	vtty_dev_count = 0;

	return ret;
}

static void __exit vtty_exit(void)
{
	unsigned int i;

	for (i = vtty_dev_count; i > 0; i--) {
		struct vtty_dev *vdev = &vtty_devs[i - 1];

		vtty_cleanup_dev(vdev);
		pr_info("vtty: /dev/%s%u target %u unloaded rx=%lld/%lld tx=%lld/%lld drop=%lld bad_len=%lld no_rx_pkt=%lld send_err=%lld\n",
			tty_dev_name, vdev->minor, vdev->target,
			atomic64_read(&vdev->stats.rx_packets),
			atomic64_read(&vdev->stats.rx_bytes),
			atomic64_read(&vdev->stats.tx_packets),
			atomic64_read(&vdev->stats.tx_bytes),
			atomic64_read(&vdev->stats.rx_dropped),
			atomic64_read(&vdev->stats.rx_bad_len),
			atomic64_read(&vdev->stats.rx_no_free_pkt),
			atomic64_read(&vdev->stats.tx_send_err));
	}

	vtty_unregister_driver();
	kfree(vtty_devs);
	vtty_devs = NULL;
	vtty_dev_count = 0;
}

module_init(vtty_init);
module_exit(vtty_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Axera");
MODULE_DESCRIPTION("AX PCIe virtual TTY driver");
